import processing
from qgis.core import *
from processing.core.ProcessingConfig import ProcessingConfig, Setting

import os

os.environ['PATH'] = '/usr/bin:' + os.environ['PATH']

QgsApplication.setPrefixPath("/usr", True)

qgs = QgsApplication([], False)
qgs.initQgis()

# 创建otb配置对象
otb_setting = Setting(ProcessingConfig.tr('General'), 'OTB_FOLDER', ProcessingConfig.tr('OTB installation folder'), True)
# 指定otb的所在目录
otb_setting.value = r'/opt/otb'

# 创建otb应用程序配置对象
otb_app_setting = Setting(ProcessingConfig.tr('General'), 'OTB_APP_FOLDER', ProcessingConfig.tr('OTB application folder'), True)
# 指定otb应用目录
otb_app_setting.value = r'/opt/otb/lib/otb/applications'

# 加载otb配置到QGIS Processing
ProcessingConfig().addSetting(otb_setting)
ProcessingConfig().addSetting(otb_app_setting)

processing.Processing().initialize()

for alg in QgsApplication.processingRegistry().algorithms():
	if 'otb' in alg.id().lower():
		print(alg.id())
# processing.algorithmHelp(alg.id())

print(len(QgsApplication.processingRegistry().algorithms()))

processing.run('gdal:merge', {
	'INPUT': ['/workdir/inputs/d63726c30a3b4243abd0aa85eabc888b_srtm_58_05.tif'],
	'OUTPUT': '/workdir/outputs/1.tif'
})

processing.run('otb:BandMath', {
	'il': ['/workdir/inputs/Landsat_wh.tif'],  # 输入影像
	'out': '/workdir/outputs/bandmath_output.tif',  # 输出影像
	'exp': '(im1b4 - im1b3) / (im1b4 + im1b3)',  # 这是一个示例表达式，im1b1和im1b2表示第一影像的第一个和第二个波段
})

print('success')
